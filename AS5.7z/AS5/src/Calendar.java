
import java.text.*;
import java.util.Date;

public class Calendar {

	private static int AvailableManPower;
	private static int AvailableMachinePower;
	private static int CManPower;
	private static int CMachinePower;
	private static Date date;

	/**
	 * 
	 * @param d1
	 * @param d2
	 */
	public int nofRepairs(Date d1, Date d2) {
		// TODO - implement Calendar.nofRepairs
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param d1
	 * @param d2
	 */
	public String TypeofRepairs(Date d1, Date d2) {
		// TODO - implement Calendar.TypeofRepairs
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param d
	 */
	public String RPO(Date d) {
		// TODO - implement Calendar.RPO
		throw new UnsupportedOperationException();
	}

	public int getCManPower() {
		// TODO - implement Calendar.getCManPower
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param CManPower
	 */
	public void setCManPower(int CManPower) {
		// TODO - implement Calendar.setCManPower
		throw new UnsupportedOperationException();
	}

	public int getCMachinePower() {
		// TODO - implement Calendar.getCMachinePower
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param CMachinePower
	 */
	public void setCMachinePower(int CMachinePower) {
		// TODO - implement Calendar.setCMachinePower
		throw new UnsupportedOperationException();
	}

	public Date getDate() {
		return this.date;
	}

	/**
	 * 
	 * @param date
	 */
	public void setDate(Date date) {
		this.date = date;
	}

}